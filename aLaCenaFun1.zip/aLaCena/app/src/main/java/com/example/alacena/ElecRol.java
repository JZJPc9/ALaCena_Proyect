package com.example.alacena;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.os.Bundle;

public class ElecRol extends AppCompatActivity {


    Button btnIng;
    Button btnCre;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elec_rol);
        //asociacion de el frontend y backend
        btnIng = findViewById(R.id.ingresar);
        btnCre = findViewById(R.id.crear);

        btnCre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //logica de el boton

            }
        });

        btnIng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //logica de el boton

            }
        });

    }
}